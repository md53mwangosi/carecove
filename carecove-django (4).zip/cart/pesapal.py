
import requests
import hashlib
import hmac
import base64
import json
from urllib.parse import urlencode, quote
from django.conf import settings
from django.urls import reverse
import time
import uuid

class PesapalService:
    """Service for integrating with Pesapal payment gateway."""
    
    def __init__(self):
        self.consumer_key = settings.PESAPAL_CONSUMER_KEY
        self.consumer_secret = settings.PESAPAL_CONSUMER_SECRET
        self.demo = settings.PESAPAL_DEMO
        
        if self.demo:
            self.base_url = 'https://cybqa.pesapal.com/pesapalv3'
        else:
            self.base_url = 'https://pay.pesapal.com/v3'
    
    def get_access_token(self):
        """Get access token from Pesapal API."""
        url = f"{self.base_url}/api/Auth/RequestToken"
        
        data = {
            'consumer_key': self.consumer_key,
            'consumer_secret': self.consumer_secret
        }
        
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        try:
            response = requests.post(url, json=data, headers=headers)
            response.raise_for_status()
            result = response.json()
            return result.get('token')
        except Exception as e:
            print(f"Error getting Pesapal token: {e}")
            return None
    
    def register_ipn_url(self, ipn_url):
        """Register IPN URL with Pesapal."""
        token = self.get_access_token()
        if not token:
            return None
        
        url = f"{self.base_url}/api/URLSetup/RegisterIPN"
        
        data = {
            'url': ipn_url,
            'ipn_notification_type': 'GET'
        }
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        try:
            response = requests.post(url, json=data, headers=headers)
            response.raise_for_status()
            result = response.json()
            return result.get('ipn_id')
        except Exception as e:
            print(f"Error registering IPN URL: {e}")
            return None
    
    def create_order(self, order_data):
        """Create payment order with Pesapal."""
        token = self.get_access_token()
        if not token:
            return None
        
        url = f"{self.base_url}/api/Transactions/SubmitOrderRequest"
        
        # Generate unique order ID
        order_id = f"CC-{int(time.time())}-{uuid.uuid4().hex[:8]}"
        
        # Prepare order data
        pesapal_order = {
            'id': order_id,
            'currency': 'TZS',
            'amount': float(order_data['total']),
            'description': f"CareCove Order - {order_data['order_number']}",
            'callback_url': order_data['callback_url'],
            'notification_id': order_data.get('notification_id', ''),
            'billing_address': {
                'email_address': order_data['email'],
                'phone_number': order_data['phone'],
                'country_code': 'TZ',
                'first_name': order_data['first_name'],
                'last_name': order_data['last_name'],
                'line_1': order_data['address_1'],
                'line_2': order_data.get('address_2', ''),
                'city': order_data['city'],
                'state': order_data['state'],
                'postal_code': order_data['postal_code'],
                'zip_code': order_data['postal_code']
            }
        }
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        try:
            response = requests.post(url, json=pesapal_order, headers=headers)
            response.raise_for_status()
            result = response.json()
            return {
                'order_tracking_id': result.get('order_tracking_id'),
                'merchant_reference': result.get('merchant_reference'),
                'redirect_url': result.get('redirect_url'),
                'pesapal_order_id': order_id
            }
        except Exception as e:
            print(f"Error creating Pesapal order: {e}")
            return None
    
    def get_transaction_status(self, order_tracking_id):
        """Get transaction status from Pesapal."""
        token = self.get_access_token()
        if not token:
            return None
        
        url = f"{self.base_url}/api/Transactions/GetTransactionStatus"
        params = {'orderTrackingId': order_tracking_id}
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            result = response.json()
            return {
                'payment_method': result.get('payment_method'),
                'amount': result.get('amount'),
                'created_date': result.get('created_date'),
                'confirmation_code': result.get('confirmation_code'),
                'payment_status_description': result.get('payment_status_description'),
                'description': result.get('description'),
                'message': result.get('message'),
                'payment_account': result.get('payment_account'),
                'call_back_url': result.get('call_back_url'),
                'status_code': result.get('status_code'),
                'merchant_reference': result.get('merchant_reference'),
                'payment_status_code': result.get('payment_status_code'),
                'currency': result.get('currency')
            }
        except Exception as e:
            print(f"Error getting transaction status: {e}")
            return None
    
    def verify_payment(self, order_tracking_id):
        """Verify payment status and return simplified result."""
        status = self.get_transaction_status(order_tracking_id)
        if not status:
            return {'success': False, 'status': 'failed', 'message': 'Unable to verify payment'}
        
        # Pesapal status codes:
        # 0 - INVALID
        # 1 - COMPLETED
        # 2 - FAILED
        # 3 - REVERSED
        status_code = status.get('status_code', 0)
        
        if status_code == 1:
            return {
                'success': True,
                'status': 'completed',
                'message': 'Payment completed successfully',
                'payment_method': status.get('payment_method'),
                'confirmation_code': status.get('confirmation_code'),
                'amount': status.get('amount'),
                'currency': status.get('currency')
            }
        elif status_code == 2:
            return {
                'success': False,
                'status': 'failed',
                'message': status.get('message', 'Payment failed'),
                'payment_method': status.get('payment_method')
            }
        elif status_code == 3:
            return {
                'success': False,
                'status': 'reversed',
                'message': 'Payment was reversed',
                'payment_method': status.get('payment_method')
            }
        else:
            return {
                'success': False,
                'status': 'pending',
                'message': 'Payment is pending',
                'payment_method': status.get('payment_method')
            }
