
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.urls import reverse
import json
import random
import string

from .models import Cart, CartItem, Order, OrderItem
from shop.models import Product, ProductVariant
from .forms import CheckoutForm
from .pesapal import PesapalService

def get_or_create_cart(request):
    """Get or create cart for user or session."""
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        if not request.session.session_key:
            request.session.create()
        cart, created = Cart.objects.get_or_create(session_key=request.session.session_key)
    return cart

def cart_detail(request):
    """Display cart contents."""
    cart = get_or_create_cart(request)
    context = {'cart': cart}
    return render(request, 'cart/cart_detail.html', context)

@require_POST
def add_to_cart(request):
    """Add product to cart."""
    product_id = request.POST.get('product_id')
    variant_id = request.POST.get('variant_id')
    quantity = int(request.POST.get('quantity', 1))
    
    product = get_object_or_404(Product, id=product_id, is_active=True)
    variant = None
    
    if variant_id:
        variant = get_object_or_404(ProductVariant, id=variant_id, product=product)
    
    cart = get_or_create_cart(request)
    
    # Check if item already in cart
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        variant=variant,
        defaults={'quantity': quantity}
    )
    
    if not created:
        cart_item.quantity += quantity
        cart_item.save()
    
    messages.success(request, f'{product.name} added to cart!')
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price)
        })
    
    return redirect('cart:cart_detail')

@require_POST
def update_cart(request):
    """Update cart item quantity."""
    item_id = request.POST.get('item_id')
    quantity = int(request.POST.get('quantity', 1))
    
    cart = get_or_create_cart(request)
    cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
    
    if quantity > 0:
        cart_item.quantity = quantity
        cart_item.save()
    else:
        cart_item.delete()
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price)
        })
    
    return redirect('cart:cart_detail')

@require_POST
def remove_from_cart(request):
    """Remove item from cart."""
    item_id = request.POST.get('item_id')
    
    cart = get_or_create_cart(request)
    cart_item = get_object_or_404(CartItem, id=item_id, cart=cart)
    cart_item.delete()
    
    messages.success(request, 'Item removed from cart.')
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'cart_total_items': cart.total_items,
            'cart_total_price': float(cart.total_price)
        })
    
    return redirect('cart:cart_detail')

def checkout(request):
    """Checkout page."""
    cart = get_or_create_cart(request)
    
    if not cart.items.exists():
        messages.error(request, 'Your cart is empty.')
        return redirect('cart:cart_detail')
    
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            # Save form data to session
            request.session['checkout_data'] = form.cleaned_data
            return redirect('cart:checkout_confirm')
    else:
        initial_data = {}
        if request.user.is_authenticated and hasattr(request.user, 'userprofile'):
            profile = request.user.userprofile
            initial_data = {
                'billing_first_name': request.user.first_name,
                'billing_last_name': request.user.last_name,
                'email': request.user.email,
                'billing_address_1': profile.default_billing_address_1,
                'billing_city': profile.default_billing_city,
                'billing_state': profile.default_billing_state,
                'billing_postal_code': profile.default_billing_postal_code,
                'billing_country': profile.default_billing_country,
                'billing_phone': profile.phone,
            }
        form = CheckoutForm(initial=initial_data)
    
    context = {
        'form': form,
        'cart': cart,
    }
    return render(request, 'cart/checkout.html', context)

def checkout_confirm(request):
    """Checkout confirmation page."""
    cart = get_or_create_cart(request)
    checkout_data = request.session.get('checkout_data')
    
    if not checkout_data:
        return redirect('cart:checkout')
    
    # Calculate totals
    subtotal = cart.total_price
    shipping_cost = 5000 if subtotal < 50000 else 0  # Free shipping over 50,000 TSH
    tax_amount = 0  # No tax for now
    total = subtotal + shipping_cost + tax_amount
    
    context = {
        'cart': cart,
        'checkout_data': checkout_data,
        'subtotal': subtotal,
        'shipping_cost': shipping_cost,
        'tax_amount': tax_amount,
        'total': total,
    }
    return render(request, 'cart/checkout_confirm.html', context)

@require_POST
def process_payment(request):
    """Process payment and create order."""
    cart = get_or_create_cart(request)
    checkout_data = request.session.get('checkout_data')
    
    if not checkout_data or not cart.items.exists():
        messages.error(request, 'Invalid checkout data.')
        return redirect('cart:checkout')
    
    # Calculate totals
    subtotal = cart.total_price
    shipping_cost = 5000 if subtotal < 50000 else 0
    tax_amount = 0
    total = subtotal + shipping_cost + tax_amount
    
    # Create order
    order = Order.objects.create(
        user=request.user if request.user.is_authenticated else None,
        email=checkout_data['email'],
        billing_first_name=checkout_data['billing_first_name'],
        billing_last_name=checkout_data['billing_last_name'],
        billing_company=checkout_data.get('billing_company', ''),
        billing_address_1=checkout_data['billing_address_1'],
        billing_address_2=checkout_data.get('billing_address_2', ''),
        billing_city=checkout_data['billing_city'],
        billing_state=checkout_data['billing_state'],
        billing_postal_code=checkout_data['billing_postal_code'],
        billing_country=checkout_data.get('billing_country', 'Tanzania'),
        billing_phone=checkout_data['billing_phone'],
        shipping_first_name=checkout_data.get('shipping_first_name', checkout_data['billing_first_name']),
        shipping_last_name=checkout_data.get('shipping_last_name', checkout_data['billing_last_name']),
        shipping_company=checkout_data.get('shipping_company', ''),
        shipping_address_1=checkout_data.get('shipping_address_1', checkout_data['billing_address_1']),
        shipping_address_2=checkout_data.get('shipping_address_2', ''),
        shipping_city=checkout_data.get('shipping_city', checkout_data['billing_city']),
        shipping_state=checkout_data.get('shipping_state', checkout_data['billing_state']),
        shipping_postal_code=checkout_data.get('shipping_postal_code', checkout_data['billing_postal_code']),
        shipping_country=checkout_data.get('shipping_country', 'Tanzania'),
        subtotal=subtotal,
        shipping_cost=shipping_cost,
        tax_amount=tax_amount,
        total=total,
        order_notes=checkout_data.get('order_notes', ''),
        payment_status='pending',
        status='pending'
    )
    
    # Create order items
    for cart_item in cart.items.all():
        OrderItem.objects.create(
            order=order,
            product=cart_item.product,
            variant=cart_item.variant,
            quantity=cart_item.quantity,
            price=cart_item.price,
            total=cart_item.total_price,
        )
    
    # Initialize Pesapal service
    pesapal = PesapalService()
    
    # Prepare order data for Pesapal
    callback_url = request.build_absolute_uri(
        reverse('cart:pesapal_callback', kwargs={'order_number': order.order_number})
    )
    
    order_data = {
        'order_number': order.order_number,
        'total': total,
        'email': checkout_data['email'],
        'phone': checkout_data['billing_phone'],
        'first_name': checkout_data['billing_first_name'],
        'last_name': checkout_data['billing_last_name'],
        'address_1': checkout_data['billing_address_1'],
        'address_2': checkout_data.get('billing_address_2', ''),
        'city': checkout_data['billing_city'],
        'state': checkout_data['billing_state'],
        'postal_code': checkout_data['billing_postal_code'],
        'callback_url': callback_url
    }
    
    # Create Pesapal order
    pesapal_response = pesapal.create_order(order_data)
    
    if pesapal_response:
        # Update order with Pesapal details
        order.pesapal_order_tracking_id = pesapal_response['order_tracking_id']
        order.pesapal_merchant_reference = pesapal_response['merchant_reference']
        order.pesapal_order_id = pesapal_response['pesapal_order_id']
        order.save()
        
        # Store order number in session for callback verification
        request.session['pending_order'] = order.order_number
        
        # Redirect to Pesapal payment page
        return redirect(pesapal_response['redirect_url'])
    else:
        # Pesapal integration failed, fall back to manual processing
        messages.error(request, 'Payment gateway temporarily unavailable. Please try again or contact support.')
        order.payment_status = 'failed'
        order.status = 'cancelled'
        order.save()
        return redirect('cart:payment_failed')

def payment_success(request):
    """Payment success page."""
    order_number = request.GET.get('order_number')
    if not order_number:
        messages.error(request, 'Invalid order reference.')
        return redirect('shop:home')
    
    order = get_object_or_404(Order, order_number=order_number)
    
    context = {'order': order}
    return render(request, 'cart/payment_success.html', context)

def payment_failed(request):
    """Payment failed page."""
    return render(request, 'cart/payment_failed.html')

def order_detail(request, order_number):
    """Order detail page."""
    order = get_object_or_404(Order, order_number=order_number)
    
    # Only allow access to order owner or staff
    if not request.user.is_staff:
        if not request.user.is_authenticated or order.user != request.user:
            messages.error(request, 'Order not found.')
            return redirect('shop:home')
    
    context = {'order': order}
    return render(request, 'cart/order_detail.html', context)

@csrf_exempt
def pesapal_callback(request, order_number):
    """Handle Pesapal payment callback."""
    order = get_object_or_404(Order, order_number=order_number)
    
    # Get the tracking ID from the request
    tracking_id = request.GET.get('OrderTrackingId')
    merchant_reference = request.GET.get('OrderMerchantReference')
    
    if not tracking_id:
        messages.error(request, 'Invalid payment callback.')
        return redirect('cart:payment_failed')
    
    # Initialize Pesapal service
    pesapal = PesapalService()
    
    # Verify payment status
    payment_result = pesapal.verify_payment(tracking_id)
    
    if payment_result['success']:
        # Payment successful
        order.payment_status = 'completed'
        order.status = 'processing'
        order.payment_reference = payment_result.get('confirmation_code', tracking_id)
        order.payment_confirmation_code = payment_result.get('confirmation_code', '')
        order.save()
        
        # Clear cart only after successful payment
        if request.session.get('pending_order') == order_number:
            # Get the user's cart and clear it
            try:
                if request.user.is_authenticated:
                    cart = Cart.objects.get(user=request.user)
                else:
                    cart = Cart.objects.get(session_key=request.session.session_key)
                cart.items.all().delete()
            except Cart.DoesNotExist:
                pass
            
            # Clear checkout data from session
            if 'checkout_data' in request.session:
                del request.session['checkout_data']
            if 'pending_order' in request.session:
                del request.session['pending_order']
        
        messages.success(request, 'Payment completed successfully!')
        return redirect(f"{reverse('cart:payment_success')}?order_number={order_number}")
    else:
        # Payment failed or pending
        if payment_result['status'] == 'failed':
            order.payment_status = 'failed'
            order.status = 'cancelled'
            order.save()
            messages.error(request, f"Payment failed: {payment_result['message']}")
            return redirect('cart:payment_failed')
        else:
            # Payment still pending
            order.payment_status = 'pending'
            order.save()
            messages.warning(request, f"Payment status: {payment_result['message']}")
            return redirect('cart:payment_failed')

@csrf_exempt
def pesapal_ipn(request):
    """Handle Pesapal IPN notifications."""
    if request.method == 'GET':
        tracking_id = request.GET.get('OrderTrackingId')
        merchant_reference = request.GET.get('OrderMerchantReference')
        
        if tracking_id and merchant_reference:
            try:
                order = Order.objects.get(pesapal_order_tracking_id=tracking_id)
                pesapal = PesapalService()
                payment_result = pesapal.verify_payment(tracking_id)
                
                if payment_result['success']:
                    order.payment_status = 'completed'
                    order.status = 'processing'
                    order.payment_reference = payment_result.get('confirmation_code', tracking_id)
                    order.payment_confirmation_code = payment_result.get('confirmation_code', '')
                    order.save()
                elif payment_result['status'] == 'failed':
                    order.payment_status = 'failed'
                    order.status = 'cancelled'
                    order.save()
                
                return HttpResponse('OK', status=200)
            except Order.DoesNotExist:
                return HttpResponse('Order not found', status=404)
    
    return HttpResponse('Invalid request', status=400)
