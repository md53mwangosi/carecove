
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import JsonResponse
from .models import Newsletter
from .forms import NewsletterForm

def subscribe(request):
    """Subscribe to newsletter."""
    if request.method == 'POST':
        form = NewsletterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            newsletter, created = Newsletter.objects.get_or_create(
                email=email,
                defaults={
                    'name': form.cleaned_data.get('name', ''),
                    'language_preference': form.cleaned_data.get('language_preference', 'en'),
                }
            )
            
            if created:
                messages.success(request, 'Thank you for subscribing to our newsletter!')
            else:
                if newsletter.is_active:
                    messages.info(request, 'You are already subscribed to our newsletter.')
                else:
                    newsletter.is_active = True
                    newsletter.save()
                    messages.success(request, 'Welcome back! Your subscription has been reactivated.')
            
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'message': 'Subscribed successfully!'})
            
            return redirect('newsletter:subscription_thank_you')
    else:
        form = NewsletterForm()
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'success': False, 'errors': form.errors})
    
    context = {'form': form}
    return render(request, 'newsletter/subscribe.html', context)

def unsubscribe(request):
    """Unsubscribe from newsletter."""
    email = request.GET.get('email')
    
    if email:
        try:
            newsletter = Newsletter.objects.get(email=email)
            newsletter.is_active = False
            newsletter.save()
            messages.success(request, 'You have been unsubscribed from our newsletter.')
        except Newsletter.DoesNotExist:
            messages.error(request, 'Email address not found in our subscription list.')
    
    return render(request, 'newsletter/unsubscribe.html')

def subscription_thank_you(request):
    """Thank you page after newsletter subscription."""
    return render(request, 'newsletter/subscription_thank_you.html')
