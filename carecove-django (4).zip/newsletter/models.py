
from django.db import models

class Newsletter(models.Model):
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=100, blank=True)
    is_active = models.BooleanField(default=True)
    language_preference = models.CharField(max_length=2, choices=[('en', 'English'), ('sw', 'Swahili')], default='en')
    subscribed_at = models.DateTimeField(auto_now_add=True)
    unsubscribed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        status = "Active" if self.is_active else "Unsubscribed"
        return f"{self.email} - {status}"

class EmailCampaign(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('scheduled', 'Scheduled'),
    ]

    subject = models.CharField(max_length=200)
    subject_sw = models.CharField(max_length=200, blank=True)
    content = models.TextField()
    content_sw = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.subject
