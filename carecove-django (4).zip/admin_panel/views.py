
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Count, Sum, Q, Avg
from django.utils import timezone
from django.core.paginator import Paginator
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.template.loader import render_to_string
from django.contrib.auth.models import User
from datetime import datetime, timedelta
import json
import csv
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

from .decorators import admin_required, ajax_required, log_admin_action
from .models import AdminActivityLog, AdminNotification, AdminSettings
from shop.models import Product, Category, ProductImage, ProductReview
from cart.models import Order, OrderItem
from accounts.models import UserProfile
from testimonials.models import Testimonial
from newsletter.models import Newsletter, EmailCampaign
from chatbot.models import ChatSession, ChatMessage, ChatbotFAQ, QuickResponse

@admin_required
def dashboard(request):
    """Main dashboard with overview statistics"""
    # Get date ranges
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    last_7_days = today - timedelta(days=7)
    
    # Orders statistics
    total_orders = Order.objects.count()
    orders_last_30_days = Order.objects.filter(created_at__gte=last_30_days).count()
    orders_last_7_days = Order.objects.filter(created_at__gte=last_7_days).count()
    
    # Revenue statistics
    total_revenue = Order.objects.filter(payment_status='completed').aggregate(
        total=Sum('total')
    )['total'] or 0
    
    revenue_last_30_days = Order.objects.filter(
        created_at__gte=last_30_days,
        payment_status='completed'
    ).aggregate(total=Sum('total'))['total'] or 0
    
    # Products statistics
    total_products = Product.objects.count()
    active_products = Product.objects.filter(is_active=True).count()
    low_stock_products = Product.objects.filter(
        stock_quantity__lt=10,
        track_inventory=True
    ).count()
    
    # Customer statistics
    total_customers = User.objects.filter(is_staff=False).count()
    new_customers_last_30_days = User.objects.filter(
        date_joined__gte=last_30_days,
        is_staff=False
    ).count()
    
    # Testimonials statistics
    pending_testimonials = Testimonial.objects.filter(status='pending').count()
    approved_testimonials = Testimonial.objects.filter(status='approved').count()
    
    # Newsletter statistics
    total_subscribers = Newsletter.objects.filter(is_active=True).count()
    
    # Recent orders
    recent_orders = Order.objects.select_related('user').order_by('-created_at')[:10]
    
    # Recent testimonials
    recent_testimonials = Testimonial.objects.order_by('-created_at')[:5]
    
    # Low stock alerts
    low_stock_alerts = Product.objects.filter(
        stock_quantity__lt=10,
        track_inventory=True,
        is_active=True
    ).order_by('stock_quantity')[:5]
    
    # Recent notifications
    recent_notifications = AdminNotification.objects.filter(is_read=False)[:5]
    
    context = {
        'total_orders': total_orders,
        'orders_last_30_days': orders_last_30_days,
        'orders_last_7_days': orders_last_7_days,
        'total_revenue': total_revenue,
        'revenue_last_30_days': revenue_last_30_days,
        'total_products': total_products,
        'active_products': active_products,
        'low_stock_products': low_stock_products,
        'total_customers': total_customers,
        'new_customers_last_30_days': new_customers_last_30_days,
        'pending_testimonials': pending_testimonials,
        'approved_testimonials': approved_testimonials,
        'total_subscribers': total_subscribers,
        'recent_orders': recent_orders,
        'recent_testimonials': recent_testimonials,
        'low_stock_alerts': low_stock_alerts,
        'recent_notifications': recent_notifications,
    }
    
    return render(request, 'admin_panel/dashboard.html', context)

@admin_required
def products_list(request):
    """List all products with filtering and search"""
    products = Product.objects.select_related('category').prefetch_related('images')
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        products = products.filter(
            Q(name__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(sku__icontains=search_query)
        )
    
    # Filter by category
    category_filter = request.GET.get('category', '')
    if category_filter:
        products = products.filter(category_id=category_filter)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter == 'active':
        products = products.filter(is_active=True)
    elif status_filter == 'inactive':
        products = products.filter(is_active=False)
    elif status_filter == 'low_stock':
        products = products.filter(stock_quantity__lt=10, track_inventory=True)
    
    # Sorting
    sort_by = request.GET.get('sort', '-created_at')
    products = products.order_by(sort_by)
    
    # Pagination
    paginator = Paginator(products, 20)
    page = request.GET.get('page')
    products = paginator.get_page(page)
    
    categories = Category.objects.all()
    
    context = {
        'products': products,
        'categories': categories,
        'search_query': search_query,
        'category_filter': category_filter,
        'status_filter': status_filter,
        'sort_by': sort_by,
    }
    
    return render(request, 'admin_panel/products/list.html', context)

@admin_required
def product_add(request):
    """Add new product"""
    if request.method == 'POST':
        try:
            # Create product
            product = Product.objects.create(
                name=request.POST['name'],
                name_sw=request.POST.get('name_sw', ''),
                category_id=request.POST['category'],
                product_type=request.POST['product_type'],
                description=request.POST['description'],
                description_sw=request.POST.get('description_sw', ''),
                price=request.POST['price'],
                compare_at_price=request.POST.get('compare_at_price') or None,
                cost_price=request.POST.get('cost_price') or None,
                stock_quantity=request.POST.get('stock_quantity', 0),
                track_inventory=request.POST.get('track_inventory') == 'on',
                allow_backorders=request.POST.get('allow_backorders') == 'on',
                weight=request.POST.get('weight') or None,
                origin=request.POST.get('origin', 'Zanzibar, Tanzania'),
                ingredients=request.POST.get('ingredients', ''),
                benefits=request.POST.get('benefits', ''),
                usage_instructions=request.POST.get('usage_instructions', ''),
                meta_title=request.POST.get('meta_title', ''),
                meta_description=request.POST.get('meta_description', ''),
                is_active=request.POST.get('is_active') == 'on',
                is_featured=request.POST.get('is_featured') == 'on',
            )
            
            # Handle image uploads
            images = request.FILES.getlist('images')
            for i, image in enumerate(images):
                ProductImage.objects.create(
                    product=product,
                    image=image,
                    alt_text=f"{product.name} - Image {i+1}",
                    is_primary=i == 0,
                    sort_order=i
                )
            
            messages.success(request, f'Product "{product.name}" added successfully!')
            return redirect('admin_panel:products_list')
            
        except Exception as e:
            messages.error(request, f'Error adding product: {str(e)}')
    
    categories = Category.objects.all()
    context = {
        'categories': categories,
        'product_types': Product.PRODUCT_TYPES,
    }
    
    return render(request, 'admin_panel/products/add.html', context)

@admin_required
def product_edit(request, product_id):
    """Edit existing product"""
    product = get_object_or_404(Product, id=product_id)
    
    if request.method == 'POST':
        try:
            # Update product
            product.name = request.POST['name']
            product.name_sw = request.POST.get('name_sw', '')
            product.category_id = request.POST['category']
            product.product_type = request.POST['product_type']
            product.description = request.POST['description']
            product.description_sw = request.POST.get('description_sw', '')
            product.price = request.POST['price']
            product.compare_at_price = request.POST.get('compare_at_price') or None
            product.cost_price = request.POST.get('cost_price') or None
            product.stock_quantity = request.POST.get('stock_quantity', 0)
            product.track_inventory = request.POST.get('track_inventory') == 'on'
            product.allow_backorders = request.POST.get('allow_backorders') == 'on'
            product.weight = request.POST.get('weight') or None
            product.origin = request.POST.get('origin', 'Zanzibar, Tanzania')
            product.ingredients = request.POST.get('ingredients', '')
            product.benefits = request.POST.get('benefits', '')
            product.usage_instructions = request.POST.get('usage_instructions', '')
            product.meta_title = request.POST.get('meta_title', '')
            product.meta_description = request.POST.get('meta_description', '')
            product.is_active = request.POST.get('is_active') == 'on'
            product.is_featured = request.POST.get('is_featured') == 'on'
            product.save()
            
            # Handle new image uploads
            images = request.FILES.getlist('images')
            for i, image in enumerate(images):
                ProductImage.objects.create(
                    product=product,
                    image=image,
                    alt_text=f"{product.name} - Image",
                    sort_order=product.images.count() + i
                )
            
            messages.success(request, f'Product "{product.name}" updated successfully!')
            return redirect('admin_panel:products_list')
            
        except Exception as e:
            messages.error(request, f'Error updating product: {str(e)}')
    
    categories = Category.objects.all()
    context = {
        'product': product,
        'categories': categories,
        'product_types': Product.PRODUCT_TYPES,
    }
    
    return render(request, 'admin_panel/products/edit.html', context)

@admin_required
@ajax_required
def product_delete(request, product_id):
    """Delete product"""
    if request.method == 'POST':
        try:
            product = get_object_or_404(Product, id=product_id)
            product_name = product.name
            product.delete()
            return JsonResponse({
                'success': True,
                'message': f'Product "{product_name}" deleted successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error deleting product: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def orders_list(request):
    """List all orders with filtering"""
    orders = Order.objects.select_related('user').prefetch_related('items')
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        orders = orders.filter(
            Q(order_number__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(billing_first_name__icontains=search_query) |
            Q(billing_last_name__icontains=search_query)
        )
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        orders = orders.filter(status=status_filter)
    
    # Filter by payment status
    payment_status_filter = request.GET.get('payment_status', '')
    if payment_status_filter:
        orders = orders.filter(payment_status=payment_status_filter)
    
    # Date filter
    date_filter = request.GET.get('date_filter', '')
    if date_filter:
        today = timezone.now().date()
        if date_filter == 'today':
            orders = orders.filter(created_at__date=today)
        elif date_filter == 'week':
            orders = orders.filter(created_at__gte=today - timedelta(days=7))
        elif date_filter == 'month':
            orders = orders.filter(created_at__gte=today - timedelta(days=30))
    
    # Sorting
    sort_by = request.GET.get('sort', '-created_at')
    orders = orders.order_by(sort_by)
    
    # Pagination
    paginator = Paginator(orders, 20)
    page = request.GET.get('page')
    orders = paginator.get_page(page)
    
    context = {
        'orders': orders,
        'search_query': search_query,
        'status_filter': status_filter,
        'payment_status_filter': payment_status_filter,
        'date_filter': date_filter,
        'sort_by': sort_by,
        'status_choices': Order.STATUS_CHOICES,
        'payment_status_choices': Order.PAYMENT_STATUS_CHOICES,
    }
    
    return render(request, 'admin_panel/orders/list.html', context)

@admin_required
def order_detail(request, order_id):
    """View order details"""
    order = get_object_or_404(Order, id=order_id)
    context = {
        'order': order,
        'status_choices': Order.STATUS_CHOICES,
        'payment_status_choices': Order.PAYMENT_STATUS_CHOICES,
    }
    return render(request, 'admin_panel/orders/detail.html', context)

@admin_required
@ajax_required
def order_update_status(request, order_id):
    """Update order status"""
    if request.method == 'POST':
        try:
            order = get_object_or_404(Order, id=order_id)
            new_status = request.POST.get('status')
            new_payment_status = request.POST.get('payment_status')
            
            if new_status:
                order.status = new_status
            if new_payment_status:
                order.payment_status = new_payment_status
            
            order.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Order status updated successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error updating order: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def customers_list(request):
    """List all customers"""
    customers = User.objects.filter(is_staff=False).select_related('userprofile')
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        customers = customers.filter(
            Q(username__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query)
        )
    
    # Sorting
    sort_by = request.GET.get('sort', '-date_joined')
    customers = customers.order_by(sort_by)
    
    # Pagination
    paginator = Paginator(customers, 20)
    page = request.GET.get('page')
    customers = paginator.get_page(page)
    
    context = {
        'customers': customers,
        'search_query': search_query,
        'sort_by': sort_by,
    }
    
    return render(request, 'admin_panel/customers/list.html', context)

@admin_required
def customer_detail(request, customer_id):
    """View customer details"""
    customer = get_object_or_404(User, id=customer_id, is_staff=False)
    orders = Order.objects.filter(user=customer).order_by('-created_at')[:10]
    
    context = {
        'customer': customer,
        'orders': orders,
    }
    
    return render(request, 'admin_panel/customers/detail.html', context)

@admin_required
def testimonials_list(request):
    """List all testimonials"""
    testimonials = Testimonial.objects.all()
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        testimonials = testimonials.filter(status=status_filter)
    
    # Sorting
    sort_by = request.GET.get('sort', '-created_at')
    testimonials = testimonials.order_by(sort_by)
    
    # Pagination
    paginator = Paginator(testimonials, 20)
    page = request.GET.get('page')
    testimonials = paginator.get_page(page)
    
    context = {
        'testimonials': testimonials,
        'status_filter': status_filter,
        'sort_by': sort_by,
        'status_choices': Testimonial.STATUS_CHOICES,
    }
    
    return render(request, 'admin_panel/testimonials/list.html', context)

@admin_required
@ajax_required
def testimonial_approve(request, testimonial_id):
    """Approve testimonial"""
    if request.method == 'POST':
        try:
            testimonial = get_object_or_404(Testimonial, id=testimonial_id)
            testimonial.status = 'approved'
            testimonial.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Testimonial approved successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error approving testimonial: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
@ajax_required
def testimonial_reject(request, testimonial_id):
    """Reject testimonial"""
    if request.method == 'POST':
        try:
            testimonial = get_object_or_404(Testimonial, id=testimonial_id)
            testimonial.status = 'rejected'
            testimonial.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Testimonial rejected successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error rejecting testimonial: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def newsletter_list(request):
    """List newsletter subscribers"""
    subscribers = Newsletter.objects.all()
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter == 'active':
        subscribers = subscribers.filter(is_active=True)
    elif status_filter == 'inactive':
        subscribers = subscribers.filter(is_active=False)
    
    # Sorting
    sort_by = request.GET.get('sort', '-subscribed_at')
    subscribers = subscribers.order_by(sort_by)
    
    # Pagination
    paginator = Paginator(subscribers, 20)
    page = request.GET.get('page')
    subscribers = paginator.get_page(page)
    
    context = {
        'subscribers': subscribers,
        'status_filter': status_filter,
        'sort_by': sort_by,
    }
    
    return render(request, 'admin_panel/newsletter/list.html', context)

@admin_required
def chatbot_management(request):
    """Manage chatbot FAQs and quick responses"""
    faqs = ChatbotFAQ.objects.all().order_by('-priority', 'category')
    quick_responses = QuickResponse.objects.all().order_by('order')
    
    context = {
        'faqs': faqs,
        'quick_responses': quick_responses,
    }
    
    return render(request, 'admin_panel/chatbot/management.html', context)

@admin_required
def analytics(request):
    """Analytics dashboard"""
    # Get date range
    days = int(request.GET.get('days', 30))
    start_date = timezone.now().date() - timedelta(days=days)
    
    # Sales data
    sales_data = Order.objects.filter(
        created_at__gte=start_date,
        payment_status='completed'
    ).extra(
        select={'date': 'date(created_at)'}
    ).values('date').annotate(
        total=Sum('total'),
        count=Count('id')
    ).order_by('date')
    
    # Popular products
    popular_products = OrderItem.objects.filter(
        order__created_at__gte=start_date,
        order__payment_status='completed'
    ).values('product__name').annotate(
        total_sold=Sum('quantity'),
        revenue=Sum('total')
    ).order_by('-total_sold')[:10]
    
    # Customer insights
    customer_stats = {
        'total_customers': User.objects.filter(is_staff=False).count(),
        'new_customers': User.objects.filter(
            date_joined__gte=start_date,
            is_staff=False
        ).count(),
        'returning_customers': Order.objects.filter(
            created_at__gte=start_date
        ).values('user').annotate(
            order_count=Count('id')
        ).filter(order_count__gt=1).count(),
    }
    
    context = {
        'sales_data': list(sales_data),
        'popular_products': list(popular_products),
        'customer_stats': customer_stats,
        'days': days,
    }
    
    return render(request, 'admin_panel/analytics/dashboard.html', context)

@admin_required
def admin_settings(request):
    """Admin settings page"""
    settings = AdminSettings.objects.all()
    context = {
        'settings': settings,
    }
    return render(request, 'admin_panel/settings/index.html', context)

@admin_required
def notifications_list(request):
    """List admin notifications"""
    notifications = AdminNotification.objects.all().order_by('-created_at')
    
    # Pagination
    paginator = Paginator(notifications, 20)
    page = request.GET.get('page')
    notifications = paginator.get_page(page)
    
    context = {
        'notifications': notifications,
    }
    
    return render(request, 'admin_panel/notifications/list.html', context)

@admin_required
def activity_logs(request):
    """View activity logs"""
    logs = AdminActivityLog.objects.select_related('user').order_by('-timestamp')
    
    # Pagination
    paginator = Paginator(logs, 50)
    page = request.GET.get('page')
    logs = paginator.get_page(page)
    
    context = {
        'logs': logs,
    }
    
    return render(request, 'admin_panel/activity_logs/index.html', context)

# Additional stub views for completeness
@admin_required
def product_images(request, product_id):
    """Manage product images"""
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'admin_panel/products/images.html', {'product': product})

@admin_required
def products_bulk_update(request):
    """Bulk update products"""
    return JsonResponse({'success': True, 'message': 'Bulk update feature coming soon!'})

@admin_required
def products_export(request):
    """Export products to CSV"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="products.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Name', 'SKU', 'Price', 'Stock', 'Category', 'Status'])
    
    for product in Product.objects.all():
        writer.writerow([
            product.name,
            product.sku,
            product.price,
            product.stock_quantity,
            product.category.name,
            'Active' if product.is_active else 'Inactive'
        ])
    
    return response

@admin_required
def order_invoice(request, order_id):
    """Generate order invoice"""
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'admin_panel/orders/invoice.html', {'order': order})

@admin_required
def orders_export(request):
    """Export orders to CSV"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="orders.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Order Number', 'Customer', 'Total', 'Status', 'Date'])
    
    for order in Order.objects.all():
        writer.writerow([
            order.order_number,
            order.email,
            order.total,
            order.status,
            order.created_at.strftime('%Y-%m-%d')
        ])
    
    return response

@admin_required
def customers_export(request):
    """Export customers to CSV"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="customers.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Username', 'Email', 'First Name', 'Last Name', 'Date Joined'])
    
    for customer in User.objects.filter(is_staff=False):
        writer.writerow([
            customer.username,
            customer.email,
            customer.first_name,
            customer.last_name,
            customer.date_joined.strftime('%Y-%m-%d')
        ])
    
    return response

@admin_required
def testimonial_feature(request, testimonial_id):
    """Feature/unfeature testimonial"""
    testimonial = get_object_or_404(Testimonial, id=testimonial_id)
    testimonial.is_featured = not testimonial.is_featured
    testimonial.save()
    
    return JsonResponse({
        'success': True,
        'message': f'Testimonial {"featured" if testimonial.is_featured else "unfeatured"} successfully!'
    })

@admin_required
def testimonial_delete(request, testimonial_id):
    """Delete testimonial"""
    if request.method == 'POST':
        testimonial = get_object_or_404(Testimonial, id=testimonial_id)
        testimonial.delete()
        return JsonResponse({'success': True, 'message': 'Testimonial deleted successfully!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def newsletter_export(request):
    """Export newsletter subscribers"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="newsletter_subscribers.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Email', 'Name', 'Status', 'Language', 'Subscribed At'])
    
    for subscriber in Newsletter.objects.all():
        writer.writerow([
            subscriber.email,
            subscriber.name,
            'Active' if subscriber.is_active else 'Inactive',
            subscriber.language_preference,
            subscriber.subscribed_at.strftime('%Y-%m-%d')
        ])
    
    return response

@admin_required
def newsletter_campaign_create(request):
    """Create newsletter campaign"""
    if request.method == 'POST':
        campaign = EmailCampaign.objects.create(
            subject=request.POST['subject'],
            subject_sw=request.POST.get('subject_sw', ''),
            content=request.POST['content'],
            content_sw=request.POST.get('content_sw', '')
        )
        messages.success(request, 'Campaign created successfully!')
        return redirect('admin_panel:newsletter_campaigns')
    
    return render(request, 'admin_panel/newsletter/campaign_create.html')

@admin_required
def newsletter_campaigns(request):
    """List newsletter campaigns"""
    campaigns = EmailCampaign.objects.all().order_by('-created_at')
    return render(request, 'admin_panel/newsletter/campaigns.html', {'campaigns': campaigns})

@admin_required
def chatbot_faq_add(request):
    """Add chatbot FAQ"""
    if request.method == 'POST':
        ChatbotFAQ.objects.create(
            question=request.POST['question'],
            keywords=request.POST['keywords'],
            answer=request.POST['answer'],
            category=request.POST['category'],
            priority=request.POST.get('priority', 0)
        )
        messages.success(request, 'FAQ added successfully!')
        return redirect('admin_panel:chatbot_management')
    
    return render(request, 'admin_panel/chatbot/faq_add.html')

@admin_required
def chatbot_faq_edit(request, faq_id):
    """Edit chatbot FAQ"""
    faq = get_object_or_404(ChatbotFAQ, id=faq_id)
    
    if request.method == 'POST':
        faq.question = request.POST['question']
        faq.keywords = request.POST['keywords']
        faq.answer = request.POST['answer']
        faq.category = request.POST['category']
        faq.priority = request.POST.get('priority', 0)
        faq.save()
        
        messages.success(request, 'FAQ updated successfully!')
        return redirect('admin_panel:chatbot_management')
    
    return render(request, 'admin_panel/chatbot/faq_edit.html', {'faq': faq})

@admin_required
def chatbot_faq_delete(request, faq_id):
    """Delete chatbot FAQ"""
    if request.method == 'POST':
        faq = get_object_or_404(ChatbotFAQ, id=faq_id)
        faq.delete()
        return JsonResponse({'success': True, 'message': 'FAQ deleted successfully!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def chatbot_quick_response_add(request):
    """Add quick response"""
    if request.method == 'POST':
        QuickResponse.objects.create(
            title=request.POST['title'],
            description=request.POST.get('description', ''),
            action_type=request.POST['action_type'],
            action_data=json.loads(request.POST.get('action_data', '{}')),
            icon=request.POST.get('icon', 'fas fa-comment'),
            order=request.POST.get('order', 0)
        )
        messages.success(request, 'Quick response added successfully!')
        return redirect('admin_panel:chatbot_management')
    
    return render(request, 'admin_panel/chatbot/quick_response_add.html')

@admin_required
def chatbot_quick_response_edit(request, qr_id):
    """Edit quick response"""
    qr = get_object_or_404(QuickResponse, id=qr_id)
    
    if request.method == 'POST':
        qr.title = request.POST['title']
        qr.description = request.POST.get('description', '')
        qr.action_type = request.POST['action_type']
        qr.action_data = json.loads(request.POST.get('action_data', '{}'))
        qr.icon = request.POST.get('icon', 'fas fa-comment')
        qr.order = request.POST.get('order', 0)
        qr.save()
        
        messages.success(request, 'Quick response updated successfully!')
        return redirect('admin_panel:chatbot_management')
    
    return render(request, 'admin_panel/chatbot/quick_response_edit.html', {'qr': qr})

@admin_required
def chatbot_quick_response_delete(request, qr_id):
    """Delete quick response"""
    if request.method == 'POST':
        qr = get_object_or_404(QuickResponse, id=qr_id)
        qr.delete()
        return JsonResponse({'success': True, 'message': 'Quick response deleted successfully!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
def chatbot_sessions(request):
    """View chatbot sessions"""
    sessions = ChatSession.objects.all().order_by('-started_at')
    
    # Pagination
    paginator = Paginator(sessions, 20)
    page = request.GET.get('page')
    sessions = paginator.get_page(page)
    
    return render(request, 'admin_panel/chatbot/sessions.html', {'sessions': sessions})

@admin_required
@ajax_required
def analytics_sales_data(request):
    """Get sales data for analytics"""
    days = int(request.GET.get('days', 30))
    start_date = timezone.now().date() - timedelta(days=days)
    
    sales_data = Order.objects.filter(
        created_at__gte=start_date,
        payment_status='completed'
    ).extra(
        select={'date': 'date(created_at)'}
    ).values('date').annotate(
        total=Sum('total'),
        count=Count('id')
    ).order_by('date')
    
    return JsonResponse(list(sales_data), safe=False)

@admin_required
@ajax_required
def analytics_products_data(request):
    """Get products data for analytics"""
    days = int(request.GET.get('days', 30))
    start_date = timezone.now().date() - timedelta(days=days)
    
    products_data = OrderItem.objects.filter(
        order__created_at__gte=start_date,
        order__payment_status='completed'
    ).values('product__name').annotate(
        total_sold=Sum('quantity'),
        revenue=Sum('total')
    ).order_by('-total_sold')[:10]
    
    return JsonResponse(list(products_data), safe=False)

@admin_required
@ajax_required
def analytics_customers_data(request):
    """Get customers data for analytics"""
    days = int(request.GET.get('days', 30))
    start_date = timezone.now().date() - timedelta(days=days)
    
    customer_stats = {
        'total_customers': User.objects.filter(is_staff=False).count(),
        'new_customers': User.objects.filter(
            date_joined__gte=start_date,
            is_staff=False
        ).count(),
        'returning_customers': Order.objects.filter(
            created_at__gte=start_date
        ).values('user').annotate(
            order_count=Count('id')
        ).filter(order_count__gt=1).count(),
    }
    
    return JsonResponse(customer_stats)

@admin_required
@ajax_required
def admin_settings_update(request):
    """Update admin settings"""
    if request.method == 'POST':
        key = request.POST.get('key')
        value = request.POST.get('value')
        
        setting, created = AdminSettings.objects.get_or_create(key=key)
        setting.value = value
        setting.save()
        
        return JsonResponse({'success': True, 'message': 'Setting updated successfully!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
@ajax_required
def notification_mark_read(request, notification_id):
    """Mark notification as read"""
    if request.method == 'POST':
        notification = get_object_or_404(AdminNotification, id=notification_id)
        notification.is_read = True
        notification.save()
        
        return JsonResponse({'success': True, 'message': 'Notification marked as read!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@admin_required
@ajax_required
def notifications_mark_all_read(request):
    """Mark all notifications as read"""
    if request.method == 'POST':
        AdminNotification.objects.filter(is_read=False).update(is_read=True)
        return JsonResponse({'success': True, 'message': 'All notifications marked as read!'})
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'})
