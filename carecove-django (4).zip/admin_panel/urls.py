
from django.urls import path
from . import views

app_name = 'admin_panel'

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Products
    path('products/', views.products_list, name='products_list'),
    path('products/add/', views.product_add, name='product_add'),
    path('products/<int:product_id>/edit/', views.product_edit, name='product_edit'),
    path('products/<int:product_id>/delete/', views.product_delete, name='product_delete'),
    path('products/<int:product_id>/images/', views.product_images, name='product_images'),
    path('products/bulk-update/', views.products_bulk_update, name='products_bulk_update'),
    path('products/export/', views.products_export, name='products_export'),
    
    # Orders
    path('orders/', views.orders_list, name='orders_list'),
    path('orders/<int:order_id>/', views.order_detail, name='order_detail'),
    path('orders/<int:order_id>/update-status/', views.order_update_status, name='order_update_status'),
    path('orders/<int:order_id>/invoice/', views.order_invoice, name='order_invoice'),
    path('orders/export/', views.orders_export, name='orders_export'),
    
    # Customers
    path('customers/', views.customers_list, name='customers_list'),
    path('customers/<int:customer_id>/', views.customer_detail, name='customer_detail'),
    path('customers/export/', views.customers_export, name='customers_export'),
    
    # Testimonials
    path('testimonials/', views.testimonials_list, name='testimonials_list'),
    path('testimonials/<int:testimonial_id>/approve/', views.testimonial_approve, name='testimonial_approve'),
    path('testimonials/<int:testimonial_id>/reject/', views.testimonial_reject, name='testimonial_reject'),
    path('testimonials/<int:testimonial_id>/feature/', views.testimonial_feature, name='testimonial_feature'),
    path('testimonials/<int:testimonial_id>/delete/', views.testimonial_delete, name='testimonial_delete'),
    
    # Newsletter
    path('newsletter/', views.newsletter_list, name='newsletter_list'),
    path('newsletter/export/', views.newsletter_export, name='newsletter_export'),
    path('newsletter/campaign/create/', views.newsletter_campaign_create, name='newsletter_campaign_create'),
    path('newsletter/campaigns/', views.newsletter_campaigns, name='newsletter_campaigns'),
    
    # Chatbot
    path('chatbot/', views.chatbot_management, name='chatbot_management'),
    path('chatbot/faq/add/', views.chatbot_faq_add, name='chatbot_faq_add'),
    path('chatbot/faq/<int:faq_id>/edit/', views.chatbot_faq_edit, name='chatbot_faq_edit'),
    path('chatbot/faq/<int:faq_id>/delete/', views.chatbot_faq_delete, name='chatbot_faq_delete'),
    path('chatbot/quick-response/add/', views.chatbot_quick_response_add, name='chatbot_quick_response_add'),
    path('chatbot/quick-response/<int:qr_id>/edit/', views.chatbot_quick_response_edit, name='chatbot_quick_response_edit'),
    path('chatbot/quick-response/<int:qr_id>/delete/', views.chatbot_quick_response_delete, name='chatbot_quick_response_delete'),
    path('chatbot/sessions/', views.chatbot_sessions, name='chatbot_sessions'),
    
    # Analytics
    path('analytics/', views.analytics, name='analytics'),
    path('analytics/sales-data/', views.analytics_sales_data, name='analytics_sales_data'),
    path('analytics/products-data/', views.analytics_products_data, name='analytics_products_data'),
    path('analytics/customers-data/', views.analytics_customers_data, name='analytics_customers_data'),
    
    # Settings
    path('settings/', views.admin_settings, name='admin_settings'),
    path('settings/update/', views.admin_settings_update, name='admin_settings_update'),
    
    # Notifications
    path('notifications/', views.notifications_list, name='notifications_list'),
    path('notifications/<int:notification_id>/read/', views.notification_mark_read, name='notification_mark_read'),
    path('notifications/mark-all-read/', views.notifications_mark_all_read, name='notifications_mark_all_read'),
    
    # Activity logs
    path('activity-logs/', views.activity_logs, name='activity_logs'),
]
